//
//  GameViewController.swift
//  SceneKit Class
//
//  Created by Henrique Figueiredo Conte on 30/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit


struct BallPosition {
    let dx: Float!
    let dy: Float!
    let dz: Float!
}

class GameViewController: UIViewController {

    let positionPossibilites: [BallPosition] = [
        BallPosition(dx: 3, dy: 0, dz: 3),
        BallPosition(dx: 2.4, dy: 0.6, dz: 3),
        BallPosition(dx: 1.8, dy: 1.2, dz: 3),
        BallPosition(dx: 1.2, dy: 1.8, dz: 3),
        BallPosition(dx: 0.6, dy: 2.4, dz: 3),
        BallPosition(dx: 0, dy: 3, dz: 3),
        BallPosition(dx: -0.6, dy: 2.4, dz: 3),
        BallPosition(dx: -1.2, dy: 1.8, dz: 3),
        BallPosition(dx: -1.8, dy: 1.2, dz: 3),
        BallPosition(dx: -2.4, dy: 0.6, dz: 3),
        BallPosition(dx: -3.0, dy: 0, dz: 3),
        BallPosition(dx: -2.4, dy: -0.6, dz: 3),
        BallPosition(dx: -1.8, dy: -1.2, dz: 3),
        BallPosition(dx: -1.2, dy: -1.8, dz: 3),
        BallPosition(dx: -0.6, dy: -2.4, dz: 3),
        BallPosition(dx: 0, dy: -3, dz: 3),
        BallPosition(dx: 0.6, dy: -2.4, dz: 3),
        BallPosition(dx: 1.2, dy: -1.8, dz: 3),
        BallPosition(dx: 1.8, dy: -1.2, dz: 3),
        BallPosition(dx: 2.4, dy: -0.6, dz: 3)
    ]
    
    let enemySpin = CABasicAnimation(keyPath: "rotation")
    
    let increaseScaleAction = SCNAction.scale(by: 1.5, duration: 0.25)
    let decreaseScaleAction = SCNAction.scale(by: 0.66, duration: 0.25)
    let gap = SCNAction.wait(duration: 0.5)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        
    
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the ship node
//        let ship = scene.rootNode.childNode(withName: "ship", recursively: true)!
        
        // animate the 3d object
  //      ship.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2, z: 0, duration: 1)))
        
        // retrieve the SCNView
        let scnView = self.view as! SCNView
        
        // set the scene to the view
        scnView.scene = scene
        
        // allows the user to manipulate the camera
        scnView.allowsCameraControl = true
        
        // show statistics such as fps and timing informationx
        scnView.showsStatistics = true
        
        // configure the view
        scnView.backgroundColor = UIColor.black
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        scnView.addGestureRecognizer(tapGesture)
    }
    
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        let scnView = self.view as! SCNView
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            
            
            if hitResults[0].node.name == "enemy" {
                
                guard let scene = (view as? SCNView)?.scene else { return }
                let waitingTime = 0.1
                let enemyNode = hitResults[0].node
                var positionCount = 0
                
                
                enemyNode.runAction(SCNAction.sequence([increaseScaleAction, decreaseScaleAction, increaseScaleAction, decreaseScaleAction, increaseScaleAction, decreaseScaleAction]))
            
                for (index, element) in scene.rootNode.childNodes.enumerated() {
                    
                    if element.name == "miniBall" {
                    
                        let xPosition = positionPossibilites[positionCount].dx! * 2
                        let yPosition = positionPossibilites[positionCount].dy! * 2
                        let zPosition = positionPossibilites[positionCount].dz! * 2
                        
                        let gap = SCNAction.wait(duration: Double(index) * waitingTime)
                        
                        let fadeIn = SCNAction.fadeIn(duration: 0.03)
                        
                        let moveToParent = SCNAction.move(to: enemyNode.position, duration: 0.01)
                        
                        let move = SCNAction.move(by: SCNVector3(x: xPosition, y: yPosition, z: zPosition), duration: 0.25)
                        
                        let fadeOut = SCNAction.fadeOut(duration: 0.178)
                        
                        let moveBack = SCNAction.move(by: SCNVector3(-xPosition, -yPosition, -zPosition), duration: 0.001)
                        
                        element.runAction(SCNAction.sequence([gap, fadeIn, moveToParent, move, fadeOut, moveBack]))
                        
                        positionCount += 1
                        
                        if positionCount >= positionPossibilites.count {
                            positionCount = 0
                        }
                    }
                    
                }
                
                
            }

        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

}
