//
//  GameScene.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 24/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import SpriteKit
import GameplayKit


struct BallPosition {
    let dx: Int!
    let dy: Int!
}


class GameScene: SKScene {
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    let positionPossibilites: [BallPosition] = [
        BallPosition(dx: 300, dy: 0),
        BallPosition(dx: 240, dy: 60),
        BallPosition(dx: 180, dy: 120),
        BallPosition(dx: 120, dy: 180),
        BallPosition(dx: 60, dy: 240),
        BallPosition(dx: 0, dy: 300),
        BallPosition(dx: -60, dy: 240),
        BallPosition(dx: -120, dy: 180),
        BallPosition(dx: -180, dy: 120),
        BallPosition(dx: -240, dy: 60),
        BallPosition(dx: -300, dy: 0),
        BallPosition(dx: -240, dy: -60),
        BallPosition(dx: -180, dy: -120),
        BallPosition(dx: -120, dy: -180),
        BallPosition(dx: -60, dy: -240),
        BallPosition(dx: 0, dy: -300),
        BallPosition(dx: 60, dy: -240),
        BallPosition(dx: 120, dy: -180),
        BallPosition(dx: 180, dy: -120),
        BallPosition(dx: 240, dy: -60)
    ]
    
    var playerNode = SKSpriteNode()
    var enemyNode = SKNode()
    
    var thePlayerNode = GKAgent2D()
    var enemyNodeAgent = GKAgent2D()
    
    var world: SKNode = SKNode()
    
    var lastTime: TimeInterval = 0.0
    
    var childrenCopy: [SKNode] = []
    
    //var attackDelayTimer = Timer()
    
    lazy var entityManager = EntityManager(scene: world)
    
    override func didMove(to view: SKView) {
        
        // Get label node from scene and store it for use later
        self.view?.backgroundColor = .lightGray
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.physicsWorld.contactDelegate = self
        
        var attackDelayTime = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(enemyAttack), userInfo: nil, repeats: true)
     //   playerNode = self.childNode(withName: "player") as! SKSpriteNode
     //   enemyNode = self.childNode(withName: "mainCircle") as! SKSpriteNode
        
        
//
//        thePlayerNode.position = vector2(0, 440)
//        thePlayerNode.maxSpeed = 100
//        thePlayerNode.mass = 0.01
//        thePlayerNode.behavior = GKBehavior(goals: [GKGoal(toSeekAgent: enemyNodeAgent)])
//        thePlayerNode.delegate = self
        
        addChild(world)
    }
    
    
    func touchDown(atPoint pos : CGPoint) {
        
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.blue
            self.addChild(n)
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.red
            self.addChild(n)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else { return }
        
        let location = touch.location(in: self)
        let previousLocation = touch.previousLocation(in: self)
        
        let touchedNodes = nodes(at: location)//atPoint(location)
        for touchedNode in touchedNodes {
            if touchedNode.name == "player" {
                
                let delta = CGVector(dx: location.x - previousLocation.x,
                                     dy: location.y - previousLocation.y)
                
                touchedNode.position.x += delta.dx
                touchedNode.position.y += delta.dy
                
            }
        }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        
        guard let location = touch?.location(in: self) else { return }
        
        let node = nodes(at: location)
        
        
        for node in node {
            if node.name == "enemy" {
                enemyNode = node
                childrenCopy = self.children.first!.children
                enemyAttack()
        }
        
            
        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
        if lastTime != 0.0 {
            entityManager.update(with: currentTime - lastTime)
            
        }
        lastTime = currentTime
    }
    
    
    func killPlayer() {
        
        for element in self.children {
            
            if element.name != "player" {
                element.position = CGPoint(x: 0, y: -300)
                
            }
            else {
                element.position = CGPoint(x: 0, y: 440)
            }
        }
        
    }
    
    
    @objc func enemyAttack() {
        
        enemyNode.run(SKAction.init(named: "emiteCircles")!, withKey: "fadeInOut")
        enemyNode.zPosition = 128
        
        let waitingTime = 0.1
        
        var positionCount = 0
        
        
        
        //for (index, element) in (childrenCopy?.enumerated())!{
        for (index, element) in (self.children.first?.children.enumerated())!{
            if element.name != "enemy" && element.name != "player" {
                
                element.setScale(0.2)
                
                let xPosition = positionPossibilites[positionCount].dx!
                let yPosition = positionPossibilites[positionCount].dy!
                
                let gap = SKAction.wait(forDuration: Double(index) * waitingTime)
                
                let fadeIn = SKAction.fadeIn(withDuration: 0.00003)
                
                let moveToParent = SKAction.move(to: enemyNode.position, duration: 0.000001)
                
                let move = SKAction.move(by: CGVector(dx: xPosition, dy: yPosition), duration: 0.25)
                
                let fadeOut = SKAction.fadeOut(withDuration: 0.178)
                
                let moveBack = SKAction.move(by: CGVector(dx: -xPosition, dy: -yPosition), duration: 0.001)
                
                element.run(SKAction.sequence([ gap, fadeIn, moveToParent, move, fadeOut, moveBack ]))
                
                positionCount += 1
                
                if positionCount >= positionPossibilites.count {
                    positionCount = 0
                }
                
            }
            
            
        }
        
        
    }
    
}


extension GameScene: SKPhysicsContactDelegate {
    
    func didBegin(_ contact: SKPhysicsContact) {
        killPlayer()
    }
    
}


extension GameScene: GKAgentDelegate {
    
    func agentWillUpdate(_ agent: GKAgent) {
        
    }
    
}
