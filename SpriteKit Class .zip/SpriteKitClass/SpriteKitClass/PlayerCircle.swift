//
//  PlayerCircle.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 29/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import GameplayKit


class PlayerCircle: GKEntity {
    
    
    override init() {
        super.init()
        
        let renderComponent = RenderComponent(node: SKNode())
        addComponent(renderComponent)
        renderComponent.node.position = CGPoint(x: 0, y: 230)
        renderComponent.node.name = "player"
        
        let spriteComponent = SpriteComponent(imageNamed: "yellow")
//        spriteComponent.spriteNode.name = "player"
        spriteComponent.spriteNode.size = CGSize(width: 150, height: 150)
        
        addComponent(spriteComponent)
        renderComponent.node.addChild(spriteComponent.spriteNode)
        
        let agentComponent = GKAgent2D()
        addComponent(agentComponent)
        agentComponent.position = vector2(Float(renderComponent.node.position.x), Float(renderComponent.node.position.y))
//        agentComponent.maxSpeed = 2
//        agentComponent.mass = 0.01
        agentComponent.radius = 0.0
        //agentComponent.behavior = GKBehavior(goals: [GKGoal(toWander: 10)])
        agentComponent.delegate = self

    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension PlayerCircle: GKAgentDelegate {
//
    func agentWillUpdate(_ agent: GKAgent) {

        guard let agent = agent as? GKAgent2D, let node = component(ofType: RenderComponent.self)?.node, !node.isPaused else { return }

        agent.position = vector2(Float(node.position.x), Float(node.position.y))

    }
//
//    func agentDidUpdate(_ agent: GKAgent) {
//        guard let agent = agent as? GKAgent2D, let node = component(ofType: RenderComponent.self)?.node, !node.isPaused else { return }
//
//        node.position =  CGPoint(x: Double(agent.position.x), y: Double(agent.position.y))
//    }

}


