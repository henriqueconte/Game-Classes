//
//  GameViewController.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 24/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    var colorAssets = ["blue", "green", "lightBlue", "lightGreen", "orange", "pink", "purple", "yellow", "blue", "green", "lightBlue", "lightGreen", "orange", "pink", "purple", "yellow"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = false
            view.showsNodeCount = false
            
            let scene = GameScene(size: view.bounds.size)
            scene.scaleMode = .aspectFit
            scene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            
            view.presentScene(scene)
            
            createEntities(for: scene)
            
        }
        
        
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    func createEntities(for scene: GameScene) {
        
        let playerCircle = PlayerCircle()
        scene.entityManager.add(entity: playerCircle)
        
        let enemyCircle = EnemyCircle(following: playerCircle)
        scene.entityManager.add(entity: enemyCircle)
        
        
        for color in colorAssets {
            let miniBall = MiniBall(colorTexture: color)
            scene.entityManager.add(entity: miniBall)
        }
        
    }
    
}
