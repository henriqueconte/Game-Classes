//
//  MiniBall.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 31/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import GameplayKit


final class MiniBall: GKEntity {
    
    init(colorTexture: String) {
        super.init()
        
        // Render
        let renderComponent = RenderComponent(node: SKNode())
        renderComponent.node.name = "miniBall"
        renderComponent.node.alpha = 0
        addComponent(renderComponent)
        
        // Sprite
        let spriteComponent = SpriteComponent(imageNamed: colorTexture)
        spriteComponent.spriteNode.name = "miniBall"
        spriteComponent.spriteNode.size = CGSize(width: 150, height: 150)
        spriteComponent.spriteNode.position = CGPoint(x: 0, y: -300)
        addComponent(spriteComponent)
        renderComponent.node.addChild(spriteComponent.spriteNode)
        
        // Autonomous
//        if let otherAgent = ball.component(ofType: GKAgent2D.self) {
//            let agentComponent = GKAgent2D()
//            addComponent(agentComponent)
//            agentComponent.position = vector2(Float(renderComponent.node.position.x),
//                                              Float(renderComponent.node.position.y))
//            agentComponent.maxSpeed = 10
//            agentComponent.mass = 0.01
//            // let wanderGoal = GKGoal(toWander: 20)
//            let seekGoal = GKGoal(toSeekAgent: otherAgent)
//            agentComponent.behavior = GKBehavior(goals:  [seekGoal], andWeights: [0.99, 0.01])
//            agentComponent.delegate = self
//        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: Agent Delegate
//extension MiniBall: GKAgentDelegate {
//
//
//    func agentWillUpdate(_ agent: GKAgent) {
//        guard let agent = agent as? GKAgent2D, let node = component(ofType: RenderComponent.self)?.node, !node.isPaused else { return }
//        agent.position = vector2(Float(node.position.x),
//                                 Float(node.position.y))
//        agent.rotation = Float(node.zRotation)
//    }
//    func agentDidUpdate(_ agent: GKAgent) {
//        guard let agent = agent as? GKAgent2D, let node = component(ofType: RenderComponent.self)?.node, !node.isPaused else { return }
//        node.position = CGPoint(x: Double(agent.position.x),
//                                y: Double(agent.position.y))
//        node.zRotation = CGFloat(agent.rotation)
//    }
//}

