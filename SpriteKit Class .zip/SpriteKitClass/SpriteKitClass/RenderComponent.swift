//
//  RenderComponent.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 29/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import GameplayKit


typealias RenderComponent = GKSKNodeComponent
