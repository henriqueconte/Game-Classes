//
//  MoveBehavior.swift
//  SpriteKitClass
//
//  Created by Henrique Figueiredo Conte on 29/07/19.
//  Copyright © 2019 Henrique Figueiredo Conte. All rights reserved.
//

import SpriteKit
import GameplayKit


class ModeBehavior: GKBehavior {
    
    init(targetSpeed: Float, seek: GKAgent) {
        super.init()
        
        if targetSpeed > 0 {

            setWeight(0.1, for: GKGoal(toReachTargetSpeed: targetSpeed))

            setWeight(0.5, for: GKGoal(toSeekAgent: seek))

        }
    }
    
    
}
